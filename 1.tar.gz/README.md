
# qiaweiadmin
基于thinkphp与aceadmin模板的后台管理系统

使用说明：

1.sql.sql文件导入到数据库中。
2.将文件App/Common/Conf/config_bak.php 重命名为config.php文件
3.在config.php文件填写数据库配置信息

后台地址：http://www.example.com/index.php/Qwadmin/   账号admin  密码 qiawei88