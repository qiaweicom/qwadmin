<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="utf-8">
<title><?php echo (C("sitename")); ?></title>
<!--link rel="stylesheet" type="text/css" href="<?php echo (C("URL")); ?>/style.css" />
<script type="text/javascript" src="<?php echo (C("URL")); ?>/js.js"></script-->
<meta name="keywords" content="<?php echo (C("keywords")); ?>" />
<meta name="description" content="<?php echo (C("description")); ?>" />
</head>
<body>
头部

尾部
<?php echo (C("footer")); ?>
</body>
</html>