<?php
return array(
	'UPDATE_URL'=>'http://update.qd.qiawei.com/',
	'NEWS_URL'=>'http://update.qd.qiawei.com/news/'
);